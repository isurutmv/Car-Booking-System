<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Created by <a href="http://techgeektechnology.com">techgeektechnology.com</a> </div>
</div>
<script src="<?php echo base_url(); ?>js/jquery.min.js"></script> 
<script src="<?php echo base_url(); ?>js/jquery.ui.custom.js"></script> 
<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script> 
<script src="<?php echo base_url(); ?>js/jquery.uniform.js"></script> 
<script src="<?php echo base_url(); ?>js/select2.min.js"></script> 
<script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script> 
<script src="<?php echo base_url(); ?>js/maruti.js"></script> 
<script src="<?php echo base_url(); ?>js/maruti.tables.js"></script>
</body>
</html>